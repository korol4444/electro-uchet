DOMAIN = "electro_uchet"
PLATFORMS = ["sensor"]
CONF_SOURCE = "source_entity"
CONF_TARIFF = "tariff"
DEFAULT_TARIFF = 6.0
DEFAULT_CURRENCY = "₽"
STORAGE_VERSION = 1
STORAGE_KEY = f"{DOMAIN}_{{entry_id}}"
